﻿# COSMIC Estimator 技能 — 安装指南

## 安装步骤

### 第1步：解压
将 cosmic-estimator 文件夹放到 Codex 工作区的 `.agents/skills/` 目录下

最终路径示例：
```
你的项目/.agents/skills/cosmic-estimator/SKILL.md
```

### 第2步：注册插件（支持 /cosmic-estimator 命令）
将 `plugin.example.json` 复制到工作区根目录，重命名为：
```
你的项目/.codex-plugin/plugin.json
```

如果已有 `.codex-plugin/plugin.json`，合并其中的 skills 和 commands 配置。

### 第3步：使用

**方式一：对话触发**
说"帮我按 COSMIC 方法估算工时"，技能会自动响应

**方式二：/ 命令**
输入 `/cosmic-estimator` 直接调用

**方式三：命令行**
```bash
cd .agents/skills/cosmic-estimator/scripts
python run_cosmic.py -i 需求文档.md -o 结果.xlsx
```

### 学习模式
生成后手动修正 xlsx，再让技能学习：
```bash
python run_cosmic.py -i 生成.xlsx --corrected 修正后.xlsx
```
