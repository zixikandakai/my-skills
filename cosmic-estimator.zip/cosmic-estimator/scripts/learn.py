﻿"""learn.py — COSMIC 学习引擎：从用户修正中持续改进"""

import json
import os
import re
from datetime import date
from collections import defaultdict
from openpyxl import load_workbook

LEARNING_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "learning")
KNOWLEDGE_PATH = os.path.join(LEARNING_DIR, "knowledge.json")


def _load_knowledge() -> dict:
    if os.path.exists(KNOWLEDGE_PATH):
        with open(KNOWLEDGE_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    return {
        "version": 2, "last_updated": "",
        "keyword_type_map": {}, "data_group_rules": {},
        "attr_patterns": {"用户基础数据": [], "基础数据": [], "数据模型": [], "配置数据": []},
        "feedback_log": []
    }


def _save_knowledge(kb: dict):
    kb["last_updated"] = str(date.today())
    with open(KNOWLEDGE_PATH, "w", encoding="utf-8") as f:
        json.dump(kb, f, ensure_ascii=False, indent=2)


def _extract_keywords(text: str) -> list:
    """提取有意义的2-4字中文关键词"""
    return list(set(re.findall(r"[\u4e00-\u9fa5]{2,4}", text)))


def learn_from_correction(gen_path: str, cor_path: str, req_name: str = ""):
    """从用户修正后的 xlsx 中学习

    Args:
        gen_path: 技能生成的原始 xlsx 路径
        cor_path: 用户手动修正后的 xlsx 路径
        req_name: 需求名称（可选）
    """
    kb = _load_knowledge()
    wb_gen = load_workbook(gen_path)["Sheet1"]
    wb_cor = load_workbook(cor_path)["Sheet1"]

    rows_gen = wb_gen.max_row - 1
    rows_cor = wb_cor.max_row - 1
    corrections = []
    type_changes = defaultdict(int)
    group_changes = defaultdict(int)

    for r in range(2, min(wb_gen.max_row, wb_cor.max_row) + 1):
        desc = wb_cor.cell(r, 5).value or ""
        orig_type = wb_gen.cell(r, 6).value or ""
        cor_type = wb_cor.cell(r, 6).value or ""
        orig_group = wb_gen.cell(r, 7).value or ""
        cor_group = wb_cor.cell(r, 7).value or ""
        orig_attrs = wb_gen.cell(r, 8).value or ""
        cor_attrs = wb_cor.cell(r, 8).value or ""

        changed = False
        entry = {"sub_process": desc, "row": r - 1}

        # 1) 数据移动类型修正
        if orig_type != cor_type and cor_type:
            entry["type_change"] = {"from": orig_type, "to": cor_type}
            type_changes[cor_type] += 1
            changed = True
            # 学习关键词映射
            for kw in _extract_keywords(desc):
                key = f"{kw}->{cor_type}"
                kb["keyword_type_map"][key] = kb["keyword_type_map"].get(key, 0) + 1

        # 2) 数据组修正
        if orig_group != cor_group and cor_group:
            entry["group_change"] = {"from": orig_group, "to": cor_group}
            group_changes[cor_group] += 1
            changed = True
            for kw in _extract_keywords(desc):
                key = f"{kw}->{cor_group}"
                kb["data_group_rules"][key] = kb["data_group_rules"].get(key, 0) + 1

        # 3) 数据属性修正
        if orig_attrs != cor_attrs and cor_attrs:
            entry["attr_change"] = {"from": orig_attrs, "to": cor_attrs}
            changed = True
            group = cor_group or "基础数据"
            if cor_attrs not in kb["attr_patterns"].setdefault(group, []):
                kb["attr_patterns"][group].append(cor_attrs)

        if changed:
            corrections.append(entry)

    # 保存反馈记录
    feedback = {
        "date": str(date.today()),
        "requirement": req_name or os.path.basename(gen_path),
        "original_rows": rows_gen,
        "corrected_rows": rows_cor,
        "corrections_count": len(corrections),
        "type_changes": dict(type_changes),
        "group_changes": dict(group_changes),
        "corrections": corrections,
    }
    kb["feedback_log"].append(feedback)

    _save_knowledge(kb)

    # 输出学习摘要
    print(f"[LEARN] 学习完成！")
    print(f"  原始: {rows_gen}行 → 修正: {rows_cor}行")
    print(f"  修正项: {len(corrections)} 处")
    if type_changes:
        print(f"  类型修正: {dict(type_changes)}")
    if group_changes:
        print(f"  数据组修正: {dict(group_changes)}")
    print(f"  知识库已更新: {KNOWLEDGE_PATH}")
    return corrections


def show_knowledge():
    """展示当前知识库状态"""
    kb = _load_knowledge()
    print(f"=== COSMIC 知识库 (v{kb['version']}) ===")
    print(f"最后更新: {kb['last_updated']}")
    print(f"关键词规则: {len(kb['keyword_type_map'])} 条")
    print(f"数据组规则: {len(kb['data_group_rules'])} 条")
    print(f"属性模板: {sum(len(v) for v in kb['attr_patterns'].values())} 条")
    print(f"历史反馈: {len(kb['feedback_log'])} 次")
    print()

    if kb["keyword_type_map"]:
        print("--- 高频学习到的关键词映射 ---")
        sorted_kw = sorted(kb["keyword_type_map"].items(), key=lambda x: -x[1])[:10]
        for key, count in sorted_kw:
            print(f"  [{key}] x{count}")


def export_learned_rules(output_path: str = ""):
    """将学到的规则导出为可配置的规则文件"""
    kb = _load_knowledge()
    if not output_path:
        output_path = os.path.join(LEARNING_DIR, "learned_rules.json")
    rules = {
        "exported": str(date.today()),
        "learned_keywords": {},
        "learned_groups": {},
        "new_attr_templates": kb.get("attr_patterns", {}),
    }
    # 汇总高频关键词映射
    for key, count in kb.get("keyword_type_map", {}).items():
        if count >= 2:  # 至少被修正过2次才算可靠
            kw, _, tp = key.partition("->")
            rules["learned_keywords"].setdefault(tp, []).append(kw)
    for key, count in kb.get("data_group_rules", {}).items():
        if count >= 2:
            kw, _, grp = key.partition("->")
            rules["learned_groups"].setdefault(grp, []).append(kw)

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(rules, f, ensure_ascii=False, indent=2)
    print(f"[OK] 规则已导出: {output_path}")
    return rules


if __name__ == "__main__":
    import sys
    if len(sys.argv) >= 3 and sys.argv[1] == "--learn":
        gen = sys.argv[2]
        cor = sys.argv[3] if len(sys.argv) > 3 else ""
        req = sys.argv[4] if len(sys.argv) > 4 else ""
        if not os.path.exists(gen):
            print(f"[ERR] 文件不存在: {gen}")
            sys.exit(1)
        if not os.path.exists(cor):
            print(f"[ERR] 文件不存在: {cor}")
            sys.exit(1)
        learn_from_correction(gen, cor, req)
    elif sys.argv[1:1] == ["--show"] if len(sys.argv) > 1 else False:
        show_knowledge()
    elif sys.argv[1:1] == ["--export"] if len(sys.argv) > 1 else False:
        export_learned_rules()
    else:
        print("用法:")
        print("  python learn.py --learn <生成文件.xlsx> <修正文件.xlsx> [需求名称]")
        print("  python learn.py --show")
        print("  python learn.py --export")
