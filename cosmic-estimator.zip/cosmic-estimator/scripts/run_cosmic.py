﻿"""run_cosmic.py — COSMIC 工时估算入口脚本

用法:
  python run_cosmic.py -i 需求文档.md -o 输出文件.xlsx
  python run_cosmic.py -i 需求文档.md -o 输出文件.xlsx --func-user "个人"
"""

import sys
import os
import argparse
import re
from typing import List, Dict
from datetime import date

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from parse_requirements import parse_simple_text, RequirementItem
from generate_xlsx import generate_xlsx


def analyze_requirement(text: str, default_func_user: str = "个人") -> List[Dict]:
    """分析需求文本，返回完整的 COSMIC 条目列表"""
    items = parse_simple_text(text)

    # 设置默认功能用户
    for item in items:
        if not item.func_user:
            item.func_user = default_func_user

    return [item.to_dict() for item in items]


def main():
    parser = argparse.ArgumentParser(description="COSMIC u5de5u65f6u4f30u7b97u5de5u5177")
    parser.add_argument("-i", "--input", required=False, help="需求文档路径 (.md/.txt)")
    parser.add_argument("-o", "--output", default="", help="输出 xlsx 路径（可选，默认自动命名）")
    parser.add_argument("--func-user", default="个人", help="功能用户名称（可选，默认“个人”）")
    parser.add_argument("--corrected", metavar="修正文件.xlsx", help="学习模式：提供修正后的 xlsx 路径，技能自动对比学习")
    parser.add_argument("--show-knowledge", action="store_true", help="展示知识库状态")
    parser.add_argument("--export-rules", action="store_true", help="导出学到的规则")
    args = parser.parse_args()

    if args.show_knowledge:
        from learn import show_knowledge
        show_knowledge()
        return
    if args.export_rules:
        from learn import export_learned_rules
        export_learned_rules()
        return
    if args.corrected:
        gen_path = args.input
        cor_path = args.corrected if args.corrected else args.output
        if not cor_path:
            print("[ERR] u5b66u4e60u6a21u5f0fu9700u8981u6307u5b9a --output u6216u76f4u63a5u63d0u4f9bu4feeu6b63u6587u4ef6u8defu5f84")
            sys.exit(1)
        from learn import learn_from_correction
        learn_from_correction(gen_path, cor_path, os.path.basename(gen_path))
        return

    input_path = args.input
    if not os.path.exists(input_path):
        print(f"[ERR] u6587u4ef6u4e0du5b58u5728: {input_path}")
        sys.exit(1)
    with open(input_path, "r", encoding="utf-8-sig") as f:
        text = f.read()
    print(f"[INFO] u8bfbu53d6u9700u6c42u6587u6863: {input_path}")

    items = analyze_requirement(text, args.func_user)
    if not items:
        print("[WARN] u672au4eceu9700u6c42u6587u6863u4e2du8bc6u522bu51fau529fu80fcu6761u76ee")
        sys.exit(0)

    print(f"[INFO] u8bc6u522bu5230 {len(items)} u6761u6570u636eu79fbu52a8")
    type_count = {}
    for item in items:
        t = item.get("data_move_type", "")
        type_count[t] = type_count.get(t, 0) + 1
    print(f"[INFO] u6570u636eu79fbu52a8u5206u5e03: {type_count}")
    print(f"[INFO] u603b CFP: {len(items)}")

    output_path = args.output
    if not output_path:
        base = os.path.splitext(os.path.basename(input_path))[0]
        output_path = f"cosmic-u4f30u7b97_{base}_{date.today().strftime('%Y%m%d')}.xlsx"

    generate_xlsx(items, output_path)

if __name__ == "__main__":
    main()

