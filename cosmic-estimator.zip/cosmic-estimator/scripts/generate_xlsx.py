﻿"""generate_xlsx.py — 按 COSMIC 模板生成 xlsx"""

from typing import List, Dict, Optional
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, Border, Side
from openpyxl.utils import get_column_letter


# === 样式常量 ===
FONT_SONG = Font(name="宋体", size=11)
FONT_YAHEI = Font(name="微软雅黑", size=11)
ALIGN_CENTER = Alignment(horizontal="center", vertical="center")
ALIGN_WRAP = Alignment(horizontal="center", vertical="center", wrap_text=True)
THIN_BORDER = Border(
    left=Side(style="thin"), right=Side(style="thin"),
    top=Side(style="thin"), bottom=Side(style="thin"),
)

# 列配置: (col, name, width, font, alignment, wrap)
COLUMNS = [
    (1,  "功能用户",   9.0,    FONT_SONG,  ALIGN_CENTER, False),
    (2,  "功能用户需求", 34.0,  FONT_SONG,  ALIGN_CENTER, False),
    (3,  "触发事件",   9.0,    FONT_SONG,  ALIGN_CENTER, False),
    (4,  "功能过程",   43.0,   FONT_SONG,  ALIGN_CENTER, False),
    (5,  "子过程描述", 81.0,   FONT_SONG,  ALIGN_CENTER, False),
    (6,  "数据移动类型", 12.0,  FONT_YAHEI, ALIGN_WRAP,   True),
    (7,  "数据组",     13.0,   FONT_SONG,  ALIGN_CENTER, False),
    (8,  "数据属性",   187.19, FONT_SONG,  ALIGN_CENTER, False),
    (9,  "调整系数",   9.0,    FONT_YAHEI, ALIGN_WRAP,   True),
    (10, "CFP",        6.0,    FONT_YAHEI, ALIGN_CENTER, False),
]

MERGE_COLS = [1, 2, 3, 4]  # A-D 列需要合并

COL_TO_KEY = {
    1: "func_user", 2: "requirement", 3: "trigger", 4: "func_process",
    5: "sub_process", 6: "data_move_type", 7: "data_group",
    8: "data_attrs", 9: "adjust_factor", 10: "cfp",
}


def generate_xlsx(items: List[Dict], output_path: str):
    """生成 COSMIC 估算 xlsx"""
    wb = Workbook()
    ws = wb.active
    ws.title = "Sheet1"

    _write_header(ws)
    _write_data(ws, items)
    _merge_cells(ws, items)
    _set_column_widths(ws)
    _set_row_heights(ws, len(items))

    wb.save(output_path)
    print(f"[OK] 已生成: {output_path}")
    print(f"[OK] 共 {len(items)} 条数据移动记录")


def _write_header(ws):
    for col_idx, name, width, font, align, wrap in COLUMNS:
        cell = ws.cell(row=1, column=col_idx, value=name)
        cell.font = font
        cell.alignment = align
        cell.border = THIN_BORDER


def _write_data(ws, items: List[Dict]):
    for i, item in enumerate(items, start=2):
        for col_idx, name, width, font, align, wrap in COLUMNS:
            key = COL_TO_KEY[col_idx]
            value = item.get(key, "")
            cell = ws.cell(row=i, column=col_idx, value=value)
            cell.border = THIN_BORDER
            cell.font = font if col_idx not in (6, 9, 10) else FONT_YAHEI
            # F列水平居中换行, H列左对齐换行, I列居中换行, J列居中
            if col_idx == 6:
                cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            elif col_idx == 8:
                cell.alignment = Alignment(vertical="center", wrap_text=True)
            elif col_idx == 9:
                cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            elif col_idx == 10:
                cell.alignment = Alignment(horizontal="center", vertical="center")
            else:
                cell.alignment = Alignment(vertical="center")


def _merge_cells(ws, items: List[Dict]):
    """合并 A-D 列中连续相同的值"""
    if not items:
        return

    for col_idx in MERGE_COLS:
        key = COL_TO_KEY[col_idx]
        start_row = 2  # 数据起始行
        prev = items[0].get(key, "")

        for i in range(1, len(items)):
            curr = items[i].get(key, "")
            if curr != prev:
                end_row = i + 1  # 上一组的最后一行 (1-based)
                if end_row > start_row:
                    ws.merge_cells(
                        start_row=start_row, start_column=col_idx,
                        end_row=end_row, end_column=col_idx,
                    )
                start_row = i + 2  # 下一组的起始行
                prev = curr

        # 处理最后一组
        last_row = len(items) + 1
        if last_row > start_row:
            ws.merge_cells(
                start_row=start_row, start_column=col_idx,
                end_row=last_row, end_column=col_idx,
            )


def _set_column_widths(ws):
    for col_idx, name, width, font, align, wrap in COLUMNS:
        ws.column_dimensions[get_column_letter(col_idx)].width = width


def _set_row_heights(ws, item_count: int):
    ws.row_dimensions[1].height = 15
    for r in range(2, item_count + 2):
        ws.row_dimensions[r].height = 15
