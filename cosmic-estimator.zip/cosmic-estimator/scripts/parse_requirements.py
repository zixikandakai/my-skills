﻿"""parse_requirements.py — 解析需求文档为结构化 COSMIC 条目"""

import re
from typing import List, Dict


class RequirementItem:
    def __init__(self, func_user: str = "", requirement: str = "",
                 trigger: str = "", func_process: str = "",
                 sub_process: str = "", data_move_type: str = "",
                 data_group: str = "", data_attrs: str = "",
                 adjust_factor: float = 1.0, cfp: int = 1):
        self.func_user = func_user
        self.requirement = requirement
        self.trigger = trigger
        self.func_process = func_process
        self.sub_process = sub_process
        self.data_move_type = data_move_type
        self.data_group = data_group
        self.data_attrs = data_attrs
        self.adjust_factor = adjust_factor
        self.cfp = cfp

    def to_dict(self) -> Dict:
        return vars(self)


TYPE_LABELS = {"E": "输入(E)", "R": "读(R)", "W": "写(W)", "X": "输出(X)"}

def _detect_move_type(desc: str) -> str:
    """检测数据移动类型，按优先级匹配"""

    # 1) 先检测开头关键词（强信号）
    if desc.startswith("输出"):
        return "X"
    if desc.startswith("输入"):
        return "E"
    if desc.startswith("接收"):
        return "E"

    # 2) 全文关键词匹配
    # E: 用户输入
    for kw in ["提交", "上传", "申请", "登记", "发送请求",
               "录入", "填写", "导入", "合规校验", "合规审核", "入栈", "接收"]:
        if kw in desc:
            return "E"

    # X: 系统输出/交付
    for kw in ["交付", "展示", "返回", "导出", "推送", "呈现", "发送通知"]:
        if kw in desc:
            return "X"

    # R: 系统读取（仅"读取"和"拉取"明确表示读）
    for kw in ["读取", "拉取", "查询", "加载", "检索", "查找", "核验"]:
        if kw in desc:
            return "R"

    # W: 写入（默认兜底）
    for kw in ["写入", "保存", "存储", "归档", "落库", "合并", "同步",
               "统计", "生成", "落地", "归集", "更新", "删除", "插入",
               "汇总", "结构化", "聚合", "关联合并", "关联", "过滤",
               "筛选", "去重", "划分", "回填", "对比", "判断", "检测",
               "获取", "取出"]:
        if kw in desc:
            return "W"
    return "W"


def _infer_data_group(desc: str, func_process: str = "") -> str:
    # 功能过程上下文：文旅专有词
    if any(w in func_process for w in ["到访", "客流", "画像", "游客", "景区", "出行数据"]):
        return "文旅数据"
    # 描述本身：文旅专有词
    if any(w in desc for w in ["画像", "游客", "旅游", "客流", "景区",
                               "到访", "游玩", "区县细化"]):
        return "文旅数据"
    # 数据模型
    if any(w in desc for w in ["模型"]):
        return "数据模型"
    # 用户基础数据
    if any(w in desc for w in ["用户", "个人", "申请", "登记"]):
        return "用户基础数据"
    # 配置数据
    if any(w in desc for w in ["配置", "参数"]):
        return "配置数据"
    # 日志数据
    if any(w in desc for w in ["日志", "记录"]):
        return "日志数据"
    return "基础数据"


ATTR_POOL = {
    "文旅数据": [
        "区县编码, 区县名称, 地市编码, 地市名称, 省份编码, 省份名称",
        "区县名称, 到访人数, 统计月份, 所属地市",
        "来源地省份名称, 到访人数, 排名, 来源类型, 数据日期",
        "景区名称, 景区到访人数, 景区排名, 游客来源地, 游客数量, 统计月份",
        "出行目的地城市, 出行人数, 出行日期, 目的地类型, 所属省份",
        "区县名称, 出行人数, 所属地市, 占比, 统计月份",
        "性别, 人数, 占比, 维度, 数据来源",
        "年龄段, 人数, 占比, 数据来源",
        "目的地名称, 目的地类型, 人数, 目的地所属省份",
        "来源地名称, 来源地类型, 到访人数, 排名序号, 数据日期",
        "景区编码, 景区名称, 景区等级, 景区类型, 到访人数, 排名",
        "用户编码, 出行目的地, 出行出发地, 出行时间, 返回时间, 出行天数",
        "省份名称, 地市名称, 区县名称, 到访人数, 出行人数",
        "性别编码, 性别名称, 人数, 占比百分比, 统计日期",
        "年龄段编码, 年龄段名称, 人数, 占比百分比, 统计日期",
        "来源地编码, 来源地名称, 来源地省份, 到访人数",
        "用户编码, 用户来源, 出行出发地, 出行目的地, 出行时间, 出行方式",
        "游客ID, 游玩景区ID, 游玩景区名称, 游玩次数, 最近游玩时间",
        "查询参数, 请求来源, 请求时间, 接口名称",
        "原始数据, 数据来源, 数据时间, 数据格式, 采集方式",
        "筛选条件, 筛选维度, 筛选结果, 数据量",
        "汇总维度, 汇总指标, 汇总结果, 统计时间, 统计周期",
        "分区维度, 分区键, 分区结果, 数据量",
        "合并字段, 合并方式, 合并结果, 合并后数据量",
        "输出参数, 输出格式, 输出路径, 输出结果, 输出时间",
        "原始客流数据, 游客来源地, 到访时间, 游客数量, 数据批次",
        "游客ID, 游玩景区, 游玩时间, 游玩次数, 评分, 消费金额",
        "出行记录ID, 出行人, 出发地, 目的地, 出行时间, 返回时间, 出行天数",
        "分析维度, 分析指标, 分析结果, 分析时间",
        "数据集名称, 数据集内容, 数据集大小, 创建时间, 更新时间",
        "查询请求ID, 查询条件, 查询结果, 查询耗时, 状态码",
        "统计口径, 统计范围, 统计指标, 统计结果, 统计人员",
        "源数据表, 目标数据表, 数据量, 执行时间, 执行状态",
        "用户画像维度, 画像标签, 画像分值, 画像时间, 画像版本",
        "目的地编码, 目的地名称, 目的地省份, 目的地类型, 热度排名",
        "用户行为ID, 行为类型, 行为时间, 行为地点, 行为详情",
        "数据变更类型, 变更前内容, 变更后内容, 变更时间, 操作人",
    ],
    "用户基础数据": [
        "imsi, 用户号码, 人社用户编码",
        "身份证, 性别, 年龄段",
        "用户手机号码、APP名称、APP类型、APP内容分类、使用流量、观看时长、使用天数",
        "文化程度, 参保地市, 是否创业人员",
        "是否参加创业培训, 是否创业人员, 职业技能鉴定等级",
    ],
    "基础数据": [
        "身份证, 性别, 参保地行政区划代码",
        "文化程度, 参保地行政区划代码, 参保地市",
        "参保类型, 是否参加创业培训, 是否参加就业技能培训",
        "是否创业人员, 职业技能鉴定等级, 是否取得职业技能鉴定证书",
        "职业技能鉴定等级, 常驻省编码, 返乡地市名称",
        "常驻省编码, 常驻省名称, 常驻地市编码",
        "常驻地市名称, 常驻区县编码, 常驻区县名称",
        "返乡省编码, 返乡省名称, 返乡地市编码",
        "返乡地市名称, 返乡区县编码, 返乡区县名称",
        "返岗省编码, 返岗省名称, 返岗地市编码",
        "返岗地市名称, 返岗区县编码, 返岗区县名称",
        "返乡类型, 返乡状态, 外出务工人员类型",
        "身份证编码, 参保地区县, 年龄",
        "年龄, 性别, 身份证前六位",
        "性别, 身份证前六位, 手机号",
        "日期, 省份编码, 地市名称",
        "手机号, 日期, 省份编码",
        "地市名称, 省份名称, 区县名称",
        "外出务工人员类型, 身份证编码, 参保地区县",
        "返岗区县编码, 外出务工人员类型, 身份证前六位",
        "人社用户编码, 文化程度, 参保地市",
        "是否参加创业培训, 是否创业人员, 职业技能鉴定等级",
        "常驻省名称, 返乡地市编码, 返岗区县名称",
        "常驻区县名称, 返乡区县编码, 返岗省名称",
        "返乡省编码, 返岗地市编码, 年龄段",
        "参保类型, 是否取得职业技能鉴定证书, 常驻地市名称",
        "用户手机号码、APP名称、APP类型、APP内容分类、上行流量、下行流量、观看时长、使用天数",
    ],
    "数据模型": [
        "省份名称, 区县名称, 人社用户编码",
        "地市名称, 省份名称, 区县名称",
        "用户手机号码、APP名称、APP类型、内容分类、相关属性、统计月份",
        "用户手机号码、内容分类、偏好分值、统计月份",
    ],
}

def _infer_data_attrs(desc: str, data_group: str) -> str:
    pool = ATTR_POOL.get(data_group, ATTR_POOL["基础数据"])
    if not pool:
        return ""
    key = "_counter_" + data_group
    if not hasattr(_infer_data_attrs, key):
        setattr(_infer_data_attrs, key, 0)
    count = getattr(_infer_data_attrs, key)
    idx = count % len(pool)
    setattr(_infer_data_attrs, key, count + 1)
    return pool[idx]

def _infer_trigger(title: str) -> str:
    """从标题提取约4个字的触发事件"""
    if not title:
        return "需求分析"
    # 常见结尾动作词
    actions = ["优化", "开发", "分析", "完善", "升级", "建设", "治理", "改造", "评估", "挖掘", "需求", "建设"]
    for a in actions:
        if title.endswith(a) and len(title) >= 4:
            prefix = title[-4:-len(a)] if len(a) == 2 else title[:2]
            return prefix + a
    # 取最后4个字
    if len(title) >= 4:
        return title[-4:]
    return title


def parse_simple_text(text: str) -> List[RequirementItem]:
    # Reset per-group attribute counters for fresh run
    attrs_to_clear = [k for k in dir(_infer_data_attrs) if k.startswith("_counter_")]
    for k in attrs_to_clear:
        delattr(_infer_data_attrs, k)
    items = []
    lines = [l.strip() for l in text.strip().split("\n") if l.strip()]

    current_func_user = "个人"
    current_requirement = ""
    current_func_process = ""

    for line in lines:
        if re.match(r"^[-=*]{3,}$", line):
            continue

        list_match = re.match(r"^[-•*]\s+(.+)$", line)
        if not list_match:
            list_match = re.match(r"^\d+[.、]\s*(.+)$", line)

        if list_match:
            desc = list_match.group(1).strip()
            if len(desc) < 4:
                continue

            move_type = _detect_move_type(desc)
            data_group = _infer_data_group(desc, current_func_process)
            data_attrs = _infer_data_attrs(desc, data_group)

            item = RequirementItem(
                func_user=current_func_user,
                requirement=current_requirement if current_requirement else "需求分析",
                trigger=_infer_trigger(current_requirement) if current_requirement else "需求分析",
                func_process=current_func_process if current_func_process else current_requirement,
                sub_process=desc,
                data_move_type=TYPE_LABELS[move_type],
                data_group=data_group,
                data_attrs=data_attrs,
                adjust_factor=1.0,
                cfp=1,
            )
            items.append(item)
            continue

        h_match = re.match(r"^#{1,3}\s+(.+)$", line)
        if h_match:
            title = h_match.group(1).strip()
            if not current_requirement:
                current_requirement = title
            elif title != current_func_process:
                current_func_process = title
            continue

        if not current_requirement and len(line) >= 4:
            current_requirement = line

    return items

